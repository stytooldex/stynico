package dump.g;

/**
 * Created by Administrator on 2015/12/9.
 */
public class BeDate<T> extends BeJson {
    private T entity;

    public T getEntity() {
        return entity;
    }
}
