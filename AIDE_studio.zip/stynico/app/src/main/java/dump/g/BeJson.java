package dump.g;

/**
 * json头信息
 */
public class BeJson {

    private int flag;
    private String msg;

    public int getFlag() {
        return flag;
    }

    public String getMsg() {
        return msg;
    }
}
