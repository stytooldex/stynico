package dump.g;


public interface HasCookieStore {

    CookieStore getCookieStore();
}
