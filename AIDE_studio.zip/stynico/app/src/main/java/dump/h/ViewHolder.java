package dump.h;

import android.widget.CheckBox;

public class ViewHolder {  
    public CheckBox a = null;  
}  
