package dump.q;

public interface ContantValue
{
  String[] viewItem = {"🇦", "🇧", "🇨", "🇩", "🇪", "🇫", "🇬","🇭", "🇮", "🇯", "🇰", "🇱", "🇲", "🇳", "🇴","🇵","🇶","🇷","🇸","🇹","🇺","🇻","🇼","🇽","🇾","🇿"};

    String[] mainItem = {"妮媌"};

}
