package dump.t;

import cn.bmob.v3.BmobObject;

public class FK__ extends BmobObject
{
	// 反馈内容
	private String content;
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
}
