package dump.v;


public interface Audience {
  void heartbeat(double fps);
}
