package dump.y;
import android.database.sqlite.SQLiteDatabase;

public interface CallBack {
	public void doSomething(SQLiteDatabase sqLiteDatabase);
}
