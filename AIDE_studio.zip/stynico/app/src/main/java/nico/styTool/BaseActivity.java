package nico.styTool;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity
{

    public int mScreenWidth;
    public int mScreenHeight;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        
        
    }

    /**
     * 关闭软键盘
     **/
    }
