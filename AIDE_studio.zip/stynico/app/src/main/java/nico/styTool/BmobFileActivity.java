package nico.styTool;

import android.annotation.SuppressLint;


@SuppressLint("SdCardPath")
public class BmobFileActivity{}
/*
extends Activity implements OnClickListener, FileChooserListener
{

    Button tv_one_one;
    private FileChooserManager fm;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_file);
	initViews();
	initListeners();
    }

    public void initViews()
    {
	// TODO Auto-generated method stub
	tv_one_one = (Button) findViewById(R.id.tv_one_one);
    }

    public void initListeners()
    {
	// TODO Auto-generated method stub
	tv_one_one.setOnClickListener(this);
    }

/*
    @Override
    public void onClick(View v)
    {
	// TODO Auto-generated method stub
	switch (v.getId())
	{
	    case R.id.tv_one_one://插入单条数据（一个BmobFile列）
		insertDataWithOne();
		break;

	}
    }


    
    }


}*/
