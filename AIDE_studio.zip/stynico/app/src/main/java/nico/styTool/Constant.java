package nico.styTool;

/**
 * Created stytool
 */
public interface Constant
{
    int NUMBER_PAGER = 20;

    String a_mi = "2017.07.17：327更新日志";
    String a_miui = "-新方案主页UI\n-兼容更多系统 \n#不忘初心#.";
    String a_ios = "";

    String httpw = "datas";
    String bin_styTool = "富强 民主 文明 和谐 自由 平等 公正 法制 爱国 敬业 诚信 友善";
    String httpkdex = "http://music.daigua.red/index.php?hm=";
    String httpkres = "http://la.vvoso.com/?qq=";
    String iddex = "http://tool.vvoso.com/tool/qiuqiu/?host=tool.vvoso.com&url=";

    String idres = "&s=3";
    String idvip = "http://hongzj.win/?hone=";
    String kii_KEY = "http://styTool.top/?hone=";
    String id = "name";
    String idKEY = "http://QQ.nico.com/subview/30877/8100505.htm?fr=aladdin&ref=wise&ssid=0&from=2001a&uid=0&pu=usm@4,sz@1320_1003,ta@iphone_2_4.4_1_10.9&bd_page_type=1&baiduid=391D799A8649F695FDA6E64F3EFBDEE1&tj=";
    String io = "123456789@:'+-,.?!:/@...;'~()<>#$%^_+-={}|qwertyuioplmknjbhvgcfxazs";
    String QQ = "2284467793";
    String android = "test";
    String USERIMG = "http://file.bmob.cn/";
    String ACTION_REGISTER_SUCCESS_FINISH = "register.success.finish";
    String TULING_KEY = "9a9e143ec4444a02d5c17892d6b4cdbf";
    String TULING_KKEY = "styTool.nico.QQ.www.wap.blog.bbs.MT2.0.com.cn.net.orghttp://ftp://@126.com@163.com@sina.com@sina.cn@hotmail.com@live.cn@gmail.com@qq.com@sohu.com";
}
