package nico.styTool;

/**
 * Created by luxin on 15-12-8.
 *  http://luxin.gitcafe.io
 */
public class HelpInfo {
    private String name;
    private String phone;
    private String explain;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getExplain() {
        return explain;
    }

    public void setExplain(String explain) {
        this.explain = explain;
    }


}
