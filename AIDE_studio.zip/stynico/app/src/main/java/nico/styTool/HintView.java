package nico.styTool;


public interface HintView {

	void initView(int length, int gravity);

	void setCurrent(int current);
}

