package nico.styTool;

public class ModuleActiveCheck {
    public static int isActiveVersion() {
        return 0xffffffff;
    }
}
