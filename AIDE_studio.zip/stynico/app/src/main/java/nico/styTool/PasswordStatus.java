package nico.styTool;

public enum PasswordStatus {
    CLOSE, SEND, DONOT_SEND
}

