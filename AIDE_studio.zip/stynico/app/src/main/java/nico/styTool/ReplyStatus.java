package nico.styTool;

public enum ReplyStatus {
    CLOSE, GOT, MISSED, ALL
}

