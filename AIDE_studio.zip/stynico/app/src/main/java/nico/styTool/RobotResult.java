package nico.styTool;

/**
 * Created by luxin on 15-12-25.
 * http://luxin.gitcafe.io
 */
public class RobotResult {
    private int code;
    private String content;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
