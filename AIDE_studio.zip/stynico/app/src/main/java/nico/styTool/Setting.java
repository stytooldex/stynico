package nico.styTool;

public class Setting {
//    private Object value;



    }
