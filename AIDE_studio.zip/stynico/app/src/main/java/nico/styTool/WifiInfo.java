package nico.styTool;

public class WifiInfo {
	public String ssid;
	public String pass;
	public String keymgmt;

	public String getSsid() {
		return ssid;
	}

	public void setSsid(String ssid) {
		this.ssid = ssid;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getKeymgmt() {
		return keymgmt;
	}

	public void setKeymgmt(String keymgmt) {
		this.keymgmt = keymgmt;
	}
}
