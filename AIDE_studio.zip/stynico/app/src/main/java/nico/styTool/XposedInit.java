package nico.styTool;

public interface XposedInit {
	String ｧ = "下";
	String ｩ = "一";
	String ｫ = "步";
}
