package nico.styTool;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.service.wallpaper.WallpaperService;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import java.io.IOException;
import dump.r.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import java.util.*;
import com.mob.mobapi.apis.*;

public class nicoWallpaper {}
