package nico.styTool;

import android.app.*;
import android.os.*;



public class sizeActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.r_dex);}}
